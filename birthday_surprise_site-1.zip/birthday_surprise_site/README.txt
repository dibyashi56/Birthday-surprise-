# Birthday Surprise Website

Open `index.html` in a browser, or upload the whole folder to GitHub Pages.

Files:
- index.html
- assets/gift.png
- assets/chat.png
- assets/monkey.png
- assets/collage.png

The buttons and Page 1–8 navigation work with HTML/CSS/JavaScript.
